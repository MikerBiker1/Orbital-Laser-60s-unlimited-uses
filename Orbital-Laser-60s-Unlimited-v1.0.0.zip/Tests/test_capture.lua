-- Usage: lua test_capture.lua SOURCE ORBITAL_TABLE_BIN
-- Fixture is the captured orbital StratagemSettings table; not bundled in release.
package.preload.ffi=function() return {} end
local function readfile(p) local f=assert(io.open(p,'rb'));local s=f:read('*a');f:close();return s end
local source=readfile(arg[1])
assert((loadstring or load)(source),'syntax')
local prefix=assert(source:match('^(.-)%-%- Runtime startup'))
local t=assert((loadstring or load)(prefix..[[
return {set_api=function(v) api=v end,patch=patch_record,found=found,state=state,matches=matches,
 word=word,u32=u32,pointer=pointer,overlay=overlay}
]]))()
local fixture=readfile(arg[2])
local rows=t.pointer(fixture,24)
local base=rows-40
local laser=rows+11*400
local original=fixture
local writes,mode,memory,reads
local function reset(which)
 mode=which;memory=original;writes={};reads=0
 t.state.seen={};t.state.records={};t.state.patched=0;t.state.rejected=0;t.state.tables=0
 t.set_api({
 read=function(address,size)
  reads=reads+1
  if address<base or address+size>base+#memory then return nil end
  return memory:sub(address-base+1,address-base+size)
 end,
 writable=function() return mode~='readonly' end,
 write=function(address,bytes)
  assert((address==laser+80 or address==laser+104) and #bytes==4,'write outside allowed fields')
  writes[#writes+1]={address,bytes}
  if mode=='second_write_fails' and #writes==2 then return false end
  memory=t.overlay(memory,address-base,bytes)
  if mode=='throw_after_write' and #writes==1 then error('simulated exception after write') end
  if mode=='corrupt' and #writes==2 then memory=t.overlay(memory,laser-base+220,'X') end
  return true
 end})
end
reset();t.found(base)
assert(t.state.patched==1 and t.state.rejected==0 and #writes==2)
local expected=t.overlay(t.overlay(original,laser-base+80,t.word(4294967295)),laser-base+104,t.word(0x42700000))
assert(memory==expected,'only requested eight bytes changed in actual capture')
local ok,why=t.patch(laser);assert(ok and why=='already patched' and #writes==2)
for _,which in ipairs({'second_write_fails','throw_after_write'}) do
 reset(which);local ok,why=t.patch(laser);assert(not ok and why:find('restored'))
 assert(memory==original,'rollback must exactly restore original capture')
end
reset('corrupt');local ok,why=t.patch(laser);assert(not ok and why:find('restored'))
assert(memory:sub(laser-base+81,laser-base+84)==original:sub(laser-base+81,laser-base+84))
assert(memory:sub(laser-base+105,laser-base+108)==original:sub(laser-base+105,laser-base+108))
reset('readonly');assert(not t.patch(laser) and #writes==0)
reset();memory=t.overlay(memory,laser-base+4,t.word(123));assert(not t.patch(laser) and #writes==0)
reset();memory=t.overlay(memory,laser-base+104,t.word(0x43950000));assert(not t.patch(laser) and #writes==0)
reset();local name=t.pointer(memory:sub(laser-base+1,laser-base+400),16)
memory=t.overlay(memory,name-base,'X');assert(not t.patch(laser) and #writes==0)
reset();local buttons=t.pointer(memory:sub(laser-base+1,laser-base+400),64)
memory=t.overlay(memory,buttons-base,t.word(4));assert(not t.patch(laser) and #writes==0)
reset();assert(not t.patch(rows) and #writes==0,'other orbital untouched')
print('PASS: real capture identification/table traversal, exactly two field writes, idempotence, rollback on write failure/exception/readback mismatch, changed ID/cooldown/name/code and wrong-stratagem rejection')
