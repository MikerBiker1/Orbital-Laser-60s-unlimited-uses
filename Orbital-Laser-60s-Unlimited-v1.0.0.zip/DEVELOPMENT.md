# Development

Source: `Source/orbital_laser_60s.lua`.

Run `python build.py PATH_TO_BingusSharedLoader [OUTPUT_ZIP]` with Python 3.10+ and
a source checkout of CowboyBingus/BingusSharedLoader. The release uses its plaintext
addon packager. Building the shared loader or extracting boot/Wwise is unnecessary.

The stable resource is `mods/custom/orbital_laser_60s`.
Manager GUID: `3c17c84c-1120-42ba-97d1-4c87c79f0434`.

The reference capture has 400-byte StratagemInfo records. Uses is uint32 at +80;
cooldown is float32 at +104. Targeting checks the Laser's IDs, localization fields,
category, name, input code, call-in delay, and original/target values. Absolute
addresses and the numeric stratagem enum from that capture are not hardcoded.
Only those two four-byte fields are written; the full record is checked afterward.
Rollback restores and checks the original values if writing or verification fails.

The cooldown currently has a numeric constant and a corresponding IEEE-754 encoding.
Both are fixed at 60 for this release. Change both if altering the source, then rebuild.
Editing the reference source inside the ZIP does not update its deployed patch.

Offline test:
`lua Tests/test_capture.lua Source/orbital_laser_60s.lua PATH_TO_ORBITAL_TABLE_BIN`

The fixture is a read-only StratagemSettings capture and is not distributed here.
Tests mock memory access and do not simulate Windows API execution or multiplayer.
