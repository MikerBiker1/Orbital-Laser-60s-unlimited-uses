-- HD2-Addon: mods/custom/orbital_laser_60s
-- Orbital Laser 60s / unlimited uses v1.0.0.
-- Layout validated against the user's September 25 StratagemSettings capture.
-- Reader/writer adapted from the user-supplied M6C addon and Dagger experiment.
if rawget(_G, 'OrbitalLaser60') then return end
local ffi_ok, ffi = pcall(require, 'ffi')
assert(ffi_ok and ffi, 'LuaJIT FFI required')
local CHUNK=262144
local MEM_COMMIT, MEM_PRIVATE=0x1000,0x20000
local PAGE_READONLY, PAGE_READWRITE=2,4
local function is_scannable_protection(p) return p==2 or p==4 end
local function build_api()
    -- Every mod shares one LuaJIT VM, so a cdef another mod already made wins. Declare
    -- one at a time and ignore redefinitions, take VirtualQuery's region as an opaque
    -- pointer so a differently-typed prior declaration still matches, and cast our own
    -- call to the typed signature.
    for _, declaration in ipairs({
        'void *GetCurrentProcess(void);',
        'int ReadProcessMemory(void *process, const void *address, void *buffer, size_t size, size_t *read);',
        'int WriteProcessMemory(void *process, void *address, const void *buffer, size_t size, size_t *written);',
        'size_t VirtualQuery(const void *address, void *region, size_t size);',
        'int VirtualProtect(void *address, size_t size, uint32_t new_protection, uint32_t *old_protection);',
        'int CreateDirectoryA(const char *path, void *security);',
        'uint32_t GetLastError(void);',
        'void *memchr(const void *s, int c, size_t n);',
        'int memcmp(const void *a, const void *b, size_t n);',
    }) do
        pcall(ffi.cdef, declaration)
    end
    -- Uniquely named so it can never collide with another mod's region struct.
    pcall(ffi.cdef, [[typedef struct {
        void *base; void *allocation_base; uint32_t allocation_protection;
        uint16_t partition; uint16_t reserved; size_t size;
        uint32_t state; uint32_t protection; uint32_t type;
    } Vg70MemoryRegion;]])

    local kernel = ffi.load('kernel32')
    local query = ffi.cast('size_t (*)(const void *, void *, size_t)', kernel.VirtualQuery)
    local virtual_protect = ffi.cast(
        'int (*)(void *, size_t, uint32_t, uint32_t *)', kernel.VirtualProtect)
    local process = kernel.GetCurrentProcess()
    local region = ffi.new('Vg70MemoryRegion[1]')
    local region_size = ffi.sizeof(region[0])
    local counter = ffi.new('size_t[1]')

    -- One scratch buffer for the whole session. Allocating a fresh one per chunk and
    -- then calling ffi.string on it to search turns every megabyte scanned into two
    -- megabytes of garbage -- and this LuaJIT VM is shared with every other mod, so
    -- that collection pressure is not ours alone to pay. Measured on LuaJIT 2.1:
    -- 118 MB/s and 2048 KB of garbage per MB, against 7599 MB/s and 0.2 KB per MB for
    -- the C search below.
    local scratch = ffi.new('uint8_t[?]', CHUNK)

    -- Needles are registered before scanning starts and all of them are looked for in
    -- the same pass over each chunk.
    local needles, longest = {}, 0

    -- memchr/memcmp are byte-exact, so this finds exactly what string.find found --
    -- including a signature at an odd alignment. If another mod declared them with
    -- incompatible types, fall back to the Lua search rather than failing outright.
    local memchr, memcmp
    local c_search = pcall(function()
        memchr, memcmp = ffi.C.memchr, ffi.C.memcmp
        local probe = ffi.new('uint8_t[4]', {1, 2, 3, 4})
        assert(memchr(probe, 3, 4) ~= nil and memcmp(probe, probe, 4) == 0)
    end)

    local self = {}
    self.c_search = c_search

    function self.add_needle(bytes)
        local entry = {text = bytes, len = #bytes, head = bytes:byte(1),
                       data = ffi.new('uint8_t[?]', #bytes)}
        ffi.copy(entry.data, bytes, #bytes)
        needles[#needles + 1] = entry
        if entry.len > longest then longest = entry.len end
        return #needles
    end

    -- Chunks must overlap by at least this much, or a needle straddling the boundary
    -- between two reads is seen by neither.
    function self.longest_needle() return longest end

    -- Pointer arguments are always cast: passing a bare Lua number raises
    -- "cannot convert number to const void *" and kills the whole scan.
    function self.read(address, size)
        if size <= 0 then return nil end
        local buffer = ffi.new('uint8_t[?]', size)
        if kernel.ReadProcessMemory(process, ffi.cast('const void *', address),
                                    buffer, size, counter) == 0 then return nil end
        if tonumber(counter[0]) ~= size then return nil end
        return ffi.string(buffer, size)
    end

    function self.write(address, bytes)
        if #bytes <= 0 then return false end
        local info = self.query(address)
        if not info or info.state ~= MEM_COMMIT or info.kind ~= MEM_PRIVATE
            or address < info.base or address + #bytes > info.base + info.size
            or (info.protection ~= PAGE_READONLY and info.protection ~= PAGE_READWRITE) then
            return false
        end
        local old_protection = ffi.new('uint32_t[1]')
        local changed = info.protection == PAGE_READONLY
        if changed and virtual_protect(ffi.cast('void *', address), #bytes,
                                       PAGE_READWRITE, old_protection) == 0 then
            return false
        end
        local wrote = kernel.WriteProcessMemory(process, ffi.cast('void *', address),
                                                bytes, #bytes, counter) ~= 0
                    and tonumber(counter[0]) == #bytes
        local restored = not changed or virtual_protect(
            ffi.cast('void *', address), #bytes, old_protection[0], old_protection) ~= 0
        return wrote and restored
    end

    function self.query(address)
        if query(ffi.cast('const void *', address), region, region_size) ~= region_size then
            return nil
        end
        local base = tonumber(ffi.cast('uintptr_t', region[0].base))
        local size = tonumber(region[0].size)
        if not base or not size or size <= 0 then return nil end
        return {base = base, size = size, state = region[0].state,
                protection = region[0].protection, kind = region[0].type,
                -- VirtualQuery's allocation base: the VirtualAlloc that owns this
                -- region. The loader lays the data tables out relative to it, which
                -- is what turns the locate below into a comparison, not a sweep.
                allocation_base = tonumber(ffi.cast('uintptr_t', region[0].allocation_base))}
    end

    -- Game data can be in committed private read-only or read/write pages. The writer
    -- temporarily opens a read-only page only for a guarded write, then restores it.
    function self.writable(address, size)
        local cursor, remaining = address, size
        while remaining > 0 do
            local info = self.query(cursor)
            if not info then return false end
            if info.state ~= MEM_COMMIT or info.kind ~= MEM_PRIVATE
                or not is_scannable_protection(info.protection) then return false end
            local available = info.base + info.size - cursor
            if available <= 0 then return false end
            if available > remaining then available = remaining end
            cursor = cursor + available
            remaining = remaining - available
        end
        return true
    end

    -- Read one chunk into the scratch buffer and report every signature hit in it.
    -- Returns false if the chunk could not be read at all.
    function self.scan(address, size, found)
        if size <= 0 or size > CHUNK then return false end
        if kernel.ReadProcessMemory(process, ffi.cast('const void *', address),
                                    scratch, size, counter) == 0 then return false end
        if tonumber(counter[0]) ~= size then return false end
        if c_search then
            for index = 1, #needles do
                local entry = needles[index]
                local cursor, remaining = scratch, size
                while remaining >= entry.len do
                    local hit = memchr(cursor, entry.head, remaining - entry.len + 1)
                    if hit == nil then break end
                    hit = ffi.cast('uint8_t *', hit)
                    local step = tonumber(hit - cursor)
                    if memcmp(hit, entry.data, entry.len) == 0 then
                        found(address + (size - remaining) + step, index)
                    end
                    remaining = remaining - step - 1
                    cursor = hit + 1
                end
            end
        else
            local blob = ffi.string(scratch, size)
            for index = 1, #needles do
                local entry = needles[index]
                local position = 1
                while true do
                    local hit = blob:find(entry.text, position, true)
                    if not hit then break end
                    found(address + hit - 1, index)
                    position = hit + 1
                end
            end
        end
        return true
    end

    function self.address_of(text)
        local ok, value = pcall(function()
            return tonumber(ffi.cast('uintptr_t', ffi.cast('const char *', text)))
        end)
        if ok then return value end
        return nil
    end

    function self.mkdir(path)
        return kernel.CreateDirectoryA(path, nil) ~= 0 or kernel.GetLastError() == 183
    end

    return self
end

-- These offsets are relative to the verified 400-byte StratagemInfo record.
local COOLDOWN_SECONDS = 60
local UNLIMITED_USES = 4294967295
local STRIDE, USES_OFFSET, COOLDOWN_OFFSET = 400,80,104
local function word(v)
    return string.char(v%256,math.floor(v/256)%256,math.floor(v/65536)%256,math.floor(v/16777216)%256)
end
local function u32(s,o)
    local a,b,c,d=s:byte(o+1,o+4);if not d then return nil end
    return a+b*256+c*65536+d*16777216
end
local function pointer(s,o)
    local lo,hi=u32(s,o),u32(s,o+4)
    if not hi or hi<1 or hi>=65536 then return nil end
    return lo+hi*4294967296
end
local function overlay(s,o,bytes) return s:sub(1,o)..bytes..s:sub(o+#bytes+1) end
local api
local state={frame=0,cursor=0,bytes=0,regions=0,tables=0,patched=0,rejected=0,done=false,seen={},records={}}
local report=function() end
local messages={}
local function log(s) messages[#messages+1]=s end
local SIGNATURE='LDLD'..word(1)..word(0x30EB6399)
local ORIGINAL_COOLDOWN=0x43960000 -- 300.0f
local TARGET_COOLDOWN=0x42700000 -- 60.0f; verified against COOLDOWN_SECONDS below
local TARGET_USES=word(UNLIMITED_USES)
local TARGET_CD=word(TARGET_COOLDOWN)
local function matches(row)
    if #row~=STRIDE or u32(row,4)~=970450596 or u32(row,8)~=759856207 then return false end
    if u32(row,40)~=3335448467 or u32(row,44)~=181783696 or u32(row,48)~=1202939756 then return false end
    if u32(row,60)~=1 or u32(row,72)~=5 or u32(row,84)~=0x40000000 then return false end
    local uses,cd=u32(row,USES_OFFSET),u32(row,COOLDOWN_OFFSET)
    if not ((uses==3 and cd==ORIGINAL_COOLDOWN) or (uses==UNLIMITED_USES and cd==TARGET_COOLDOWN)) then return false end
    local name_ptr,buttons_ptr=pointer(row,16),pointer(row,64)
    if not name_ptr or not buttons_ptr then return false end
    if api.read(name_ptr,15)~='ORBITAL. LASER\0' then return false end
    return api.read(buttons_ptr,20)==word(2)..word(3)..word(1)..word(2)..word(3)
end
local function patch_record(address)
    local before=api.read(address,STRIDE)
    if not before or not matches(before) then return false,'identity or baseline mismatch' end
    if u32(before,USES_OFFSET)==UNLIMITED_USES then return true,'already patched' end
    if not api.writable(address+USES_OFFSET,4) or not api.writable(address+COOLDOWN_OFFSET,4) then
        return false,'record is not writable'
    end
    local old_uses=before:sub(USES_OFFSET+1,USES_OFFSET+4)
    local old_cd=before:sub(COOLDOWN_OFFSET+1,COOLDOWN_OFFSET+4)
    local function rollback(reason)
        local ok1,w1=pcall(api.write,address+USES_OFFSET,old_uses)
        local ok2,w2=pcall(api.write,address+COOLDOWN_OFFSET,old_cd)
        local r1,b1=pcall(api.read,address+USES_OFFSET,4)
        local r2,b2=pcall(api.read,address+COOLDOWN_OFFSET,4)
        if not(ok1 and w1 and ok2 and w2 and r1 and r2 and b1==old_uses and b2==old_cd) then
            return false,reason..'; ROLLBACK FAILED - restart game'
        end
        return false,reason..'; original values restored'
    end
    local ok,wrote=pcall(api.write,address+USES_OFFSET,TARGET_USES)
    if not ok or not wrote then return rollback('uses write failed') end
    ok,wrote=pcall(api.write,address+COOLDOWN_OFFSET,TARGET_CD)
    if not ok or not wrote then return rollback('cooldown write failed') end
    local read_ok,after=pcall(api.read,address,STRIDE)
    local expected=overlay(overlay(before,USES_OFFSET,TARGET_USES),COOLDOWN_OFFSET,TARGET_CD)
    if not read_ok or after~=expected then return rollback('full-record readback failed') end
    return true,'patched and verified'
end
local own_signature
local function found(address)
    if state.seen[address] or (own_signature and math.abs(address-own_signature)<4096) then return end
    state.seen[address]=true
    local head=api.read(address,40)
    if not head or head:sub(1,12)~=SIGNATURE then return end
    local size,count=u32(head,12),u32(head,32)
    local rows_ptr=pointer(head,24)
    if not size or size<16 or size>1048576 or not count or count<1 or count>2048 or not rows_ptr then return end
    if count*STRIDE>size-16 then return end
    local rows=api.read(rows_ptr,count*STRIDE)
    if not rows then return end
    state.tables=state.tables+1
    local candidate=nil
    for i=0,count-1 do
        local row=rows:sub(i*STRIDE+1,(i+1)*STRIDE)
        if u32(row,4)==970450596 then
            if candidate then log('REFUSED: duplicate Laser IDs in table');state.rejected=state.rejected+1;return end
            candidate=rows_ptr+i*STRIDE
        end
    end
    if not candidate or state.records[candidate] then return end
    state.records[candidate]=true
    local ok,why=patch_record(candidate)
    if ok then state.patched=state.patched+1 else state.rejected=state.rejected+1 end
    log((ok and 'OK: ' or 'REFUSED: ')..why)
    report('SCANNING')
end
-- Runtime startup (offline tests load only the functions above with a mock API).
api=build_api()
assert(COOLDOWN_SECONDS==60,'Recompute TARGET_COOLDOWN if editing the cooldown constant')
local loader=rawget(_G,'CowboyBingusModLoader')
assert(type(loader)=='table' and loader.api==1,'Bingus Shared Loader API 1 required')
assert(type(update)=='function','game update unavailable')
_G.OrbitalLaser60=state
local base=assert(os.getenv('LOCALAPPDATA'),'LOCALAPPDATA missing')
for _,part in ipairs({'CowboyBingus','Helldivers2','OrbitalLaser60'}) do
    base=base..'/'..part;assert(api.mkdir(base),'cannot create diagnostics directory')
end
report=function(phase)
    local f=io.open(base..'/STATUS.txt','wb');if not f then return end
    f:write(phase..'\nOrbital Laser: 60-second BASE cooldown / unlimited uses\nPatched: '..state.patched..
        '\nRejected: '..state.rejected..'\nTables: '..state.tables..'\nFrames: '..state.frame..'\nBytes scanned: '..state.bytes..
        '\n'..table.concat(messages,'\n')..'\n');f:close()
end
api.add_needle(SIGNATURE);own_signature=api.address_of(SIGNATURE)
local current=nil
local function tick()
    state.frame=state.frame+1
    if state.frame<120 then return end
    local deadline=os.clock()+0.0015
    while os.clock()<deadline do
        if not current then
            if state.cursor>=0x7FFFFFFF0000 or state.regions>200000 then state.done=true;break end
            local info=api.query(state.cursor)
            if not info then state.done=true;break end
            local next_address=info.base+info.size
            if next_address<=state.cursor then error('region enumeration did not advance') end
            state.cursor=next_address;state.regions=state.regions+1
            if info.state==MEM_COMMIT and info.kind==MEM_PRIVATE and is_scannable_protection(info.protection) then
                current={address=info.base,remaining=info.size}
            end
        else
            local n=math.min(CHUNK,current.remaining)
            api.scan(current.address,n,found);state.bytes=state.bytes+n
            if n==current.remaining then current=nil else
                local step=n-11;current.address=current.address+step;current.remaining=current.remaining-step
            end
        end
    end
    if state.done then
        local result=state.patched>0 and state.rejected==0 and 'OK - patch verified; scan finished' or 'INCOMPLETE - see results below'
        report(result)
    end
end
local previous=update
local function pack(...) return {n=select('#',...),...} end
local function after(...)
    local r=pack(...);local ok,err=pcall(tick)
    if not ok then state.done=true;log(tostring(err));pcall(report,'FAILED') end
    return unpack(r,1,r.n)
end
update=function(...)
    if state.done then return previous(...) end
    return after(previous(...))
end
report('WAITING - startup scan begins after 120 frames')
