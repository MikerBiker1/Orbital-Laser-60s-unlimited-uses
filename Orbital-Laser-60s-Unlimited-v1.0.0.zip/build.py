"""Build release using BingusSharedLoader's public single-entry packager."""
from pathlib import Path
import sys,json,zipfile,tempfile
ROOT=Path(__file__).resolve().parent
if len(sys.argv)<2: raise SystemExit('Usage: python build.py PATH_TO_BingusSharedLoader [OUTPUT_ZIP]')
sys.path.insert(0,str(Path(sys.argv[1]).resolve()/'scripts'))
from build_addon import build_addon
out=Path(sys.argv[2]).resolve() if len(sys.argv)>2 else ROOT/'Orbital-Laser-60s-Unlimited-v1.0.0.zip'
with tempfile.TemporaryDirectory() as temp:
    base=Path(temp)/'base.zip'
    build_addon('mods/custom/orbital_laser_60s',(ROOT/'Source/orbital_laser_60s.lua').read_bytes(),
        '3c17c84c-1120-42ba-97d1-4c87c79f0434',base,'Orbital Laser - 60s Cooldown & Unlimited Uses v1.0.0')
    with zipfile.ZipFile(base) as z: files={name:z.read(name) for name in z.namelist()}
    manifest=json.loads(files['manifest.json'])
    description='Orbital Laser: 60-second base cooldown and unlimited mission uses. Requires Bingus Shared Loader v15+ / API 1. Upgrades and mission modifiers may affect cooldown.'
    manifest['Description']=description
    manifest['Options'][0]['Name']='60s Base Cooldown + Unlimited Uses'
    manifest['Options'][0]['Description']=description
    files['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
    for name in ['README.md','DESCRIPTION.txt','CHANGELOG.md','DEVELOPMENT.md','VALIDATION.txt','build.py','Source/orbital_laser_60s.lua','Tests/test_capture.lua']:
        files[name]=(ROOT/name).read_bytes()
    with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED) as z:
        for name,data in sorted(files.items()):
            info=zipfile.ZipInfo(name,date_time=(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
            info.external_attr=0o100644<<16;z.writestr(info,data)
print(out)
